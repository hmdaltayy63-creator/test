(function(){
  var STAGE_NAMES=['الأولى','الثانية','الثالثة','الرابعة'];
  /* Two kinds of place with the same rules: halls (collection "halls") and labs (collection "labs"). */
  var FAC={
    halls:{col:'halls',ids:['h1','h2','h3','h4'],tab:'القاعات الدراسية',one:'القاعة',
      free:'متاحة',busy:'محجوزة',notBooked:'غير محجوزة',offer:'متاحة للحجز',busyOther:'محجوزة لأستاذ آخر',
      bookBtn:'احجز القاعة',leaveBtn:'مغادرة القاعة',justBooked:'هذه القاعة انحجزت قبل لحظات.',
      pick:'القاعة التي تريدها',four:'القاعات الأربع',boardTitle:'حالة القاعات الآن',
      stuTitle:'حالة القاعات',stuLead:'اطلع على القاعات المحجوزة والمتاحة الآن، ومن الأستاذ الموجود فيها. الصفحة تتحدث تلقائياً.'},
    labs:{col:'labs',ids:['l1','l2','l3','l4'],tab:'المختبرات العملية',one:'المختبر',
      free:'متاح',busy:'محجوز',notBooked:'غير محجوز',offer:'متاح للحجز',busyOther:'محجوز لأستاذ آخر',
      bookBtn:'احجز المختبر',leaveBtn:'مغادرة المختبر',justBooked:'هذا المختبر انحجز قبل لحظات.',
      pick:'المختبر الذي تريده',four:'المختبرات الأربعة',boardTitle:'حالة المختبرات الآن',
      stuTitle:'حالة المختبرات',stuLead:'اطلع على المختبرات المحجوزة والمتاحة الآن، ومن الأستاذ الموجود فيها. الصفحة تتحدث تلقائياً.'}
  };
  var fac='halls';
  try{var sf=localStorage.getItem('fac');if(sf&&FAC[sf])fac=sf;}catch(e){}
  function F(){return FAC[fac];}
  var ST={halls:{},labs:{}};                 // facility -> id -> document data
  var STAT={halls:'loading',labs:'loading'}; // loading | live | offline

  function stageName(s){return STAGE_NAMES[Number(s)-1]||'';}
  function selStage(){var p=document.querySelector('input[name="stage"]:checked');return p?Number(p.value):1;}
  /* the active booking (if any) that already holds this stage, in any place of the current kind */
  function stageTaken(stg){
    if(STAT[fac]!=='live')return null;
    var ids=F().ids;
    for(var i=0;i<ids.length;i++){
      var d=ST[fac][ids[i]];
      if(d&&d.status==='booked'&&Number(d.stage)===stg)return {id:ids[i],d:d};
    }
    return null;
  }
  function bookedCount(f){
    var n=0;
    FAC[f].ids.forEach(function(id){var d=ST[f][id];if(d&&d.status==='booked')n++;});
    return n;
  }

  var VIEWS=['home','head','prof','students','reader','log'];
  var curView='home';
  var navStack=[], lastKey='home', goingBack=false;   // in-site "back" steps
  var busy={}, confirmId=null, confirmTimer=null;
  var offsetMs=0;          // فرق ساعة الخادم عن ساعة الجهاز
  var me=null;             // signed-in lecturer {id,name}
  var head=null;           // signed-in department head {id,name}
  var profs=[], delId=null, delTimer=null;
  var hTab='profs';        // department head tabs: profs | screen

  var AR='٠١٢٣٤٥٦٧٨٩';
  function ar(v){return String(v).replace(/\d/g,function(d){return AR[d];});}
  function el(tag,cls,text){var n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;}
  function $(s){return document.querySelector(s);}

  function nowMs(){return Date.now()+offsetMs;}   // ساعة الخادم
  /* Baghdad time (UTC+3, no daylight saving), the same on every device */
  var TZ_MS=3*3600*1000;
  function pad2(n){return String(n).padStart(2,'0');}
  function clock(ts){
    var d=new Date(ts+TZ_MS),h=d.getUTCHours(),m=d.getUTCMinutes(),s=h>=12?'م':'ص';
    h=h%12||12;
    return ar(h+':'+pad2(m))+' '+s;
  }
  function dayKey(ts){
    var d=new Date(ts+TZ_MS);
    return d.getUTCFullYear()+'-'+pad2(d.getUTCMonth()+1)+'-'+pad2(d.getUTCDate());
  }
  function fmtDay(key){
    var p=key.split('-');
    var d=new Date(Date.UTC(Number(p[0]),Number(p[1])-1,Number(p[2]),12));
    return ar(d.toLocaleDateString('ar-IQ',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}));
  }
  function hms(ms){
    ms=Math.max(0,Math.floor(ms/1000));
    var h=Math.floor(ms/3600),m=Math.floor(ms%3600/60),s=ms%60;
    return ar([h,m,s].map(function(n){return String(n).padStart(2,'0');}).join(':'));
  }
  function dur(ms){
    var t=Math.round(ms/60000),h=Math.floor(t/60),m=t%60,p=[];
    if(t<1)return 'أقل من دقيقة';
    if(h===1)p.push('ساعة');else if(h===2)p.push('ساعتان');
    else if(h>2&&h<11)p.push(ar(h)+' ساعات');else if(h>=11)p.push(ar(h)+' ساعة');
    if(m>0)p.push(m===1?'دقيقة':m===2?'دقيقتان':m<11?ar(m)+' دقائق':ar(m)+' دقيقة');
    return p.join(' و');
  }

  function view(id){
    var st=STAT[fac];
    if(st!=='live')return {k:st==='offline'?'off':'load'};
    var d=ST[fac][id];
    if(!d)return {k:'free'};
    if(d.status==='booked')return {k:'busy',d:d};
    if(d.endedAt)return {k:'left',d:d};
    return {k:'free'};
  }
  function W(k){return k==='load'?'جارٍ التحقق':k==='off'?'غير متصل':k==='busy'?F().busy:F().free;}

  function chip(k,word){
    var c=el('span','chip');c.append(el('span','lamp'),document.createTextNode(word));return c;
  }
  function availTag(){return el('span','avail','متاح الآن');}

  /* ---------- lecturers: booking ---------- */
  function renderHalls(){
    var root=$('#hall-grid'),L=F();
    root.replaceChildren.apply(root,L.ids.map(function(id,i){
      var v=view(id),ck=v.k==='left'?'free':v.k,card=el('article','hall '+ck),top=el('div','hall-top'),n=el('div');
      n.append(el('span','cap',L.one),el('span','num',ar(i+1)));
      top.append(n,chip(ck,W(v.k)));

      var det=el('div','detail'),btn=el('button','btn'),mine=false,taken=null;
      btn.type='button';btn.dataset.id=id;
      if(v.k==='busy'){
        mine=!!v.d.mine;
        det.append(el('strong','',v.d.professor||'—'),el('span','','المرحلة '+stageName(v.d.stage)),el('span','','منذ '+clock(v.d.startedAt)));
        var t=el('span','timer');t.dataset.start=v.d.startedAt;t.textContent=hms(nowMs()-v.d.startedAt);
        det.append(t);
        btn.dataset.act='leave';
        btn.className='btn leave'+(confirmId===id?' sure':'');
        btn.textContent=!mine?L.busyOther:confirmId===id?'اضغط مرة ثانية للتأكيد':L.leaveBtn;
      }else{
        det.append(el('strong','',v.k==='load'?'…':v.k==='off'?'تعذر الاتصال':L.offer));
        if(v.k==='left')det.append(el('span','','آخر محاضرة انتهت '+clock(v.d.endedAt)),availTag());
        btn.dataset.act='book';
        btn.textContent=L.bookBtn;
        if(v.k==='free'||v.k==='left'){
          taken=stageTaken(selStage());
          if(taken){
            det.append(el('span','','المرحلة '+stageName(selStage())+' محجوزة في '+L.one+' '+ar(L.ids.indexOf(taken.id)+1)+' باسم '+(taken.d.professor||'—')));
            btn.textContent='المرحلة محجوزة';
          }
        }
      }
      btn.disabled=!!busy[id]||v.k==='load'||v.k==='off'||(v.k==='busy'&&!mine)||!!taken;
      card.append(top,det,btn);
      return card;
    }));
  }

  /* ---------- students: who is in, since when ---------- */
  function renderStudents(){
    var root=$('#stu-grid'),L=F();
    root.replaceChildren.apply(root,L.ids.map(function(id,i){
      var v=view(id),card=el('article','hall '+v.k),top=el('div','hall-top'),n=el('div');
      n.append(el('span','cap',L.one),el('span','num',ar(i+1)));
      top.append(n,chip(v.k,v.k==='left'?'غادر الأستاذ':W(v.k)));
      var det=el('div','detail');
      if(v.k==='busy'){
        det.append(el('strong','',v.d.professor||'—'),el('span','','المرحلة '+stageName(v.d.stage)),el('span','','منذ '+clock(v.d.startedAt)));
        var t=el('span','timer');t.dataset.start=v.d.startedAt;t.textContent=hms(nowMs()-v.d.startedAt);
        det.append(t);
      }else if(v.k==='left'){
        det.append(el('strong','',v.d.professor||'—'),el('span','','المرحلة '+stageName(v.d.stage)),
          el('span','','من '+clock(v.d.startedAt)+' إلى '+clock(v.d.endedAt)),
          el('span','','مدة المحاضرة: '+dur(v.d.endedAt-v.d.startedAt)),availTag());
      }else{
        det.append(el('strong','',v.k==='load'?'…':v.k==='off'?'تعذر الاتصال':L.notBooked));
      }
      card.append(top,det);
      return card;
    }));
  }

  /* ---------- hallway display board ---------- */
  function renderBoard(sel){
    var root=$(sel),L=F();
    root.replaceChildren.apply(root,L.ids.map(function(id,i){
      var v=view(id),row=el('article','row '+v.k),num=el('div','r-num'),main=el('div','r-main'),time=el('div','r-time');
      num.append(el('span','cap',L.one),el('span','num',ar(i+1)));
      var word=v.k==='left'?'غادر الأستاذ':W(v.k);
      main.append(chip(v.k,word));
      if(v.k==='left')main.append(availTag());
      if(v.k==='busy'){
        main.append(el('div','r-name',v.d.professor||'—'),el('div','r-meta','المرحلة '+stageName(v.d.stage)+' · بدأ الحجز '+clock(v.d.startedAt)));
        var t=el('span','r-val');t.dataset.start=v.d.startedAt;t.textContent=hms(nowMs()-v.d.startedAt);
        time.append(t,el('span','r-cap','مضى من الحجز'));
      }else if(v.k==='left'){
        main.append(el('div','r-name',v.d.professor||'—'),el('div','r-meta','المرحلة '+stageName(v.d.stage)+' · من '+clock(v.d.startedAt)+' إلى '+clock(v.d.endedAt)));
        time.append(el('span','r-val',dur(v.d.endedAt-v.d.startedAt)),el('span','r-cap','مدة المحاضرة'));
      }else if(v.k==='free'){
        main.append(el('div','r-meta','لا توجد محاضرة الآن'));
      }else{
        main.append(el('div','r-meta',v.k==='off'?'تعذر قراءة حالة '+L.one:'جارٍ قراءة حالة '+L.one));
      }
      row.append(num,main,time);
      return row;
    }));
  }

  /* ---------- department head: lecturers list ---------- */
  function renderProfs(){
    var ul=$('#plist');
    if(!profs.length){ul.replaceChildren(el('li','','لا يوجد أساتذة بعد. أضف أول أستاذ من الأعلى.'));return;}
    ul.replaceChildren.apply(ul,profs.slice().sort(function(a,b){return a.name.localeCompare(b.name,'ar');}).map(function(p){
      var li=el('li'),b=el('button','link',delId===p.id?'اضغط للتأكيد':'إزالة');
      b.type='button';b.dataset.pid=p.id;
      li.append(el('span','',p.name),b);
      return li;
    }));
  }
  function renderSessions(){
    $('#login').hidden=!!me;
    $('#session').hidden=!me;
    if(me)$('#me-name').textContent=me.name;
    $('#h-login').hidden=!!head;
    $('#h-session').hidden=!head;
    $('#h-tabs').hidden=!head;
    $('#h-panel').hidden=!head||hTab!=='profs';
    $('#h-screen').hidden=!head||hTab!=='screen';
    document.querySelectorAll('#h-tabs button').forEach(function(b){
      b.setAttribute('aria-pressed',b.dataset.t===hTab?'true':'false');
    });
    if(head)$('#h-name').textContent=head.name;
  }

  /* ---------- side rail: halls / labs ---------- */
  function renderRail(){
    var nav=$('#factabs');
    nav.replaceChildren.apply(nav,['halls','labs'].map(function(f){
      var b=el('button');b.type='button';b.dataset.f=f;
      b.setAttribute('aria-pressed',f===fac?'true':'false');
      b.append(el('b','',FAC[f].tab),el('small','',STAT[f]==='live'?ar(bookedCount(f))+' من '+ar(FAC[f].ids.length)+' قيد الاستخدام':'…'));
      return b;
    }));
    var show=curView!=='home'&&curView!=='log'&&!(curView==='head'&&(!head||hTab!=='screen'));
    nav.hidden=!show;
    $('#shell').classList.toggle('norail',!show);
  }
  $('#factabs').addEventListener('click',function(ev){
    var b=ev.target.closest('button[data-f]');
    if(!b||b.dataset.f===fac)return;
    fac=b.dataset.f;confirmId=null;say('');
    try{localStorage.setItem('fac',fac);}catch(e){}
    renderAll();
  });

  function renderAll(){
    var L=F();
    renderSessions();renderProfs();renderRail();
    $('#stu-title').textContent=L.stuTitle;
    $('#stu-lead').textContent=L.stuLead;
    $('#board-title').textContent=L.boardTitle;
    $('#h-board-title').textContent=L.boardTitle;
    $('#prof-hint').textContent='اختر مرحلة محاضرتك ثم اضغط على '+L.pick+'. '+L.four+' مشتركة بين كل المراحل.';
    renderHalls();renderStudents();renderBoard('#board');renderBoard('#h-board');
    if(curView==='log')renderLog();
    var n=$('#notice');
    if(STAT.halls==='offline'){n.textContent='تعذر الاتصال بالسيرفر. تأكد من اتصالك بالشبكة، وسيعيد الموقع المحاولة تلقائياً.';n.hidden=false;}
    else n.hidden=true;
  }

  /* ---------- clocks (display only, no writes) ---------- */
  function tick(){
    var now=nowMs();
    document.querySelectorAll('[data-start]').forEach(function(n){n.textContent=hms(now-Number(n.dataset.start));});
    var d=new Date(now);
    $('#now-time').textContent=clock(now);
    $('#now-date').textContent=ar(d.toLocaleDateString('ar-IQ',{weekday:'long',day:'numeric',month:'long',timeZone:'Asia/Baghdad'}));
  }
  setInterval(tick,1000);

  /* ---------- daily log: one document per booking in collection "log" ---------- */
  var logStage=0;          // 0 = no stage picked yet, 1..4 = stage whose history is shown
  var logDay=dayKey(nowMs()), logReady=false, logErr=false, logDocs=[], logTimer=null, logReq=0;
  async function loadLog(){
    var key=logDay, req=++logReq;
    try{
      var r=await api('GET','/api/log?day='+encodeURIComponent(key));
      if(req!==logReq||key!==logDay)return;
      logDocs=r.items;logReady=true;logErr=false;
    }catch(e){
      if(req!==logReq)return;
      logErr=true;logReady=true;
    }
    renderLog();
  }
  function stopLog(){if(logTimer){clearInterval(logTimer);logTimer=null;}}
  function watchLog(){
    stopLog();
    logReady=false;logErr=false;logDocs=[];
    renderLog();loadLog();
    logTimer=setInterval(loadLog,5000);
  }
  function setLogDay(key){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(key))return;
    logDay=key;watchLog();
  }
  function shiftDay(delta){
    var p=logDay.split('-');
    var d=new Date(Date.UTC(Number(p[0]),Number(p[1])-1,Number(p[2]))+delta*86400000);
    setLogDay(d.getUTCFullYear()+'-'+pad2(d.getUTCMonth()+1)+'-'+pad2(d.getUTCDate()));
  }
  function renderStageGrid(){
    var g=$('#stage-grid');
    g.replaceChildren.apply(g,STAGE_NAMES.map(function(name,i){
      var a=el('a');a.href='#log-'+(i+1);
      if(logStage===i+1)a.setAttribute('aria-current','page');
      a.append(el('small','','المرحلة'),el('b','',name));
      return a;
    }));
  }
  function renderLog(){
    var body=$('#log-body');
    renderStageGrid();
    $('#log-hint').hidden=!!logStage;
    $('#log-detail').hidden=!logStage;
    if(!logStage)return;
    $('#day-pick').value=logDay;
    $('#day-label').textContent='المرحلة '+stageName(logStage)+' · '+fmtDay(logDay)+(logDay===dayKey(nowMs())?' (اليوم)':'');
    if(!logReady){body.replaceChildren(el('p','hint','جارٍ تحميل السجل…'));return;}
    if(logErr){body.replaceChildren(el('p','hint','تعذر تحميل سجل هذا اليوم، حاول مرة ثانية.'));return;}
    var parts=['halls','labs'].map(function(f){
      var L=FAC[f],sec=el('section','logsec');
      var rows=logDocs.filter(function(r){return r.fac===f&&Number(r.stage)===logStage;}).sort(function(a,b){return (a.startedAt||0)-(b.startedAt||0);});
      sec.append(el('h3','',L.tab+' · '+(rows.length?ar(rows.length)+(rows.length===1?' حجز':' حجوزات'):'لا توجد حجوزات')));
      if(!rows.length){sec.append(el('p','hint','لم يُحجز أي '+(f==='halls'?'قاعة':'مختبر')+' لهذه المرحلة في هذا اليوم.'));return sec;}
      var ul=el('ul','loglist');
      rows.forEach(function(r){
        var li=el('li','logrow'+(r.endedAt?'':' on')),idx=L.ids.indexOf(r.place)+1;
        var pl=el('div','lg-place'),main=el('div','lg-main'),end=el('div','lg-end');
        pl.append(el('span','cap',L.one),el('span','lg-n',idx?ar(idx):'؟'));
        main.append(el('b','',r.professor||'—'),
          el('span','','من '+clock(r.startedAt)+(r.endedAt?' إلى '+clock(r.endedAt):' · ما زالت جارية')));
        if(r.endedAt){end.append(el('b','',dur(r.endedAt-r.startedAt)),el('span','cap','مدة المحاضرة'));}
        else{
          var t=el('span','timer');t.dataset.start=r.startedAt;t.textContent=hms(nowMs()-r.startedAt);
          end.append(chip('busy','جارية الآن'),t);
        }
        li.append(pl,main,end);ul.append(li);
      });
      sec.append(ul);
      return sec;
    });
    body.replaceChildren.apply(body,parts);
  }
  $('#day-prev').addEventListener('click',function(){shiftDay(-1);});
  $('#day-next').addEventListener('click',function(){shiftDay(1);});
  $('#day-today').addEventListener('click',function(){setLogDay(dayKey(nowMs()));});
  $('#day-pick').addEventListener('change',function(){setLogDay(this.value);});

  /* ---------- motivational messages for students ---------- */
  var QUOTES=[
    'كل جسر عظيم بدأ بمخطط صغير على ورقة. ابدأ مخططك اليوم.',
    'المهندس لا ينتظر الظروف المثالية، بل يصمم الحل بما هو متاح.',
    'التعب في الدراسة اليوم هو الأساس الذي ستقف عليه إنجازاتك غداً.',
    'الخطأ في المختبر درس، والخطأ الحقيقي هو الذي لا نتعلم منه.',
    'لا تقارن فصلك الأول بفصل غيرك الأخير. كل بناء يبدأ بأساس.',
    'اسأل كثيراً. أفضل المهندسين هم أكثرهم أسئلة.',
    'المعادلة الصعبة تُحل خطوة بخطوة، مثل أي مشروع كبير.',
    'نصف الإنجاز أن تحضر، والنصف الآخر أن تثابر.',
    'كل ساعة مراجعة اليوم توفر عليك ليلة قلق في الامتحان.',
    'بلدك ينتظر مهندسين مثلك، فاجعل كل يوم دراسة لبنة في طريقك.',
    'الرسوب في مادة لا يعني الفشل في الطريق، بل يعني أن المسار يحتاج تعديلاً.',
    'اعمل بذكاء وثابر بصبر، فالمشاريع الكبيرة لا تُبنى في ليلة.',
    'ركّز على التقدم لا على الكمال.',
    'زميلك الذي تساعده اليوم قد يكون شريكك في أول مشروع لك غداً. ساعد وتعلّم.',
    'عندما تتعثر، تذكّر أن كل دائرة كهربائية معقدة بدأت بسلك واحد.',
    'النجاح ليس صدفة، إنه جدول منتظم وعزيمة لا تنطفئ.',
    'اكتب ملاحظاتك بيدك، فالفكرة التي تكتبها ترسخ أكثر.',
    'ثق بقدرتك على الفهم، فالصعب مجرد سهل لم تألفه بعد.',
    'أنت لا تدرس لتنجح في امتحان فقط، بل لتبني شيئاً يخدم الناس.',
    'استراحة قصيرة اليوم تعني تركيزاً أعلى غداً. اعتنِ بنفسك.',
    'المهندس الجيد يحوّل المشكلة إلى فرصة، والمشكلة اليوم اسمها امتحان.',
    'كل يوم تتعلم فيه فكرة جديدة هو يوم لم يضع.',
    'لا يهم كم مرة فشلت التجربة، المهم أن تعدّل التصميم وتعيد المحاولة.',
    'اجعل هدفك أكبر من خوفك.',
    'الانضباط يصنع ما لا تصنعه الموهبة وحدها.',
    'ابدأ بالمادة الأصعب وأنت في أوج نشاطك، والباقي سيبدو أسهل.',
    'من يجتهد اليوم يصمم مستقبله بيده.',
    'حلم التخرج مهندساً يستحق السهر أحياناً، لكن لا تنسَ نومك.',
    'تذكّر لماذا اخترت الهندسة: لأنك تحب أن تصنع شيئاً يعمل.',
    'كن فخوراً بخطوتك الصغيرة، فهي أول خطوة في مشروعك الكبير.'
  ];
  var lastQ=-1;
  function nextQuote(){
    var seen=[],pool=[],i;
    try{seen=JSON.parse(localStorage.getItem('q-seen')||'[]');}catch(e){seen=[];}
    if(!Array.isArray(seen))seen=[];
    for(i=0;i<QUOTES.length;i++)if(seen.indexOf(i)<0&&i!==lastQ)pool.push(i);
    if(!pool.length){seen=[];for(i=0;i<QUOTES.length;i++)if(i!==lastQ)pool.push(i);}
    var pick=pool[Math.floor(Math.random()*pool.length)];
    seen.push(pick);lastQ=pick;
    try{localStorage.setItem('q-seen',JSON.stringify(seen));}catch(e){}
    return QUOTES[pick];
  }

  /* ---------- الاتصال بالخادم (Flask) ---------- */
  async function api(method,url,body){
    var opt={method:method,credentials:'same-origin',headers:{'X-Requested-With':'iku'}};
    if(body!==undefined){opt.headers['Content-Type']='application/json';opt.body=JSON.stringify(body);}
    var res;
    try{res=await fetch(url,opt);}
    catch(e){var ne=new Error('network');ne.network=true;throw ne;}
    var data=null;
    try{data=await res.json();}catch(e){}
    if(!res.ok){
      var err=new Error((data&&data.code)||('http_'+res.status));
      err.status=res.status;err.data=data||{};
      throw err;
    }
    return data;
  }

  /* حالة القاعات والمختبرات والجلسة تُجلب من الخادم كل 3 ثوانٍ، ولا تُرسم الصفحة إلا إذا تغير شيء */
  var refreshing=false, lastSig='';
  async function refresh(){
    if(refreshing)return;
    refreshing=true;
    var changed=false;
    try{
      var s=await api('GET','/api/state');
      offsetMs=s.now-Date.now();
      var sig=JSON.stringify([s.halls,s.labs,s.me,s.head,s.professors]);
      if(sig!==lastSig||STAT.halls!=='live'){
        lastSig=sig;
        ST.halls=s.halls;ST.labs=s.labs;
        me=s.me;head=s.head;profs=s.professors||[];
        STAT.halls='live';STAT.labs='live';
        changed=true;
      }
    }catch(e){
      if(STAT.halls!=='offline'){STAT.halls='offline';STAT.labs='offline';changed=true;}
    }finally{refreshing=false;}
    if(changed)renderAll();
  }

  /* ---------- messages ---------- */
  function say(text,isErr){
    var m=$(curView==='head'?'#h-msg':'#msg');
    m.textContent=text;m.className='msg'+(isErr?' err':'');
  }

  /* ---------- sign-in: الخادم يتحقق من الرمز ويحفظ الجلسة في كوكي ---------- */
  async function signIn(kind,code){
    code=(code||'').trim();
    if(!code){say('أدخل الرمز أولاً.',true);return;}
    try{
      await api('POST','/api/login',{kind:kind,code:code});
      $(kind==='head'?'#h-code':'#code').value='';say('');
    }catch(e){
      if(e.network)say('تعذر الاتصال بالسيرفر.',true);
      else if(e.status===429)say('محاولات خاطئة كثيرة. انتظر بضع دقائق ثم حاول.',true);
      else if(e.status===401)say('الرمز غير صحيح.',true);
      else say('تعذر التحقق من الرمز، حاول مرة ثانية.',true);
    }
    await refresh();
  }
  async function signOut(kind){
    confirmId=null;say('');
    try{await api('POST','/api/logout',{kind:kind});}catch(e){}
    await refresh();
  }
  $('#login-btn').addEventListener('click',function(){signIn('prof',$('#code').value);});
  $('#code').addEventListener('keydown',function(ev){if(ev.key==='Enter')signIn('prof',$('#code').value);});
  $('#logout').addEventListener('click',function(){signOut('prof');});
  $('#h-login-btn').addEventListener('click',function(){signIn('head',$('#h-code').value);});
  $('#h-code').addEventListener('keydown',function(ev){if(ev.key==='Enter')signIn('head',$('#h-code').value);});
  $('#h-logout').addEventListener('click',function(){signOut('head');});

  try{
    var sv=localStorage.getItem('prof-stage');
    var sr=sv&&document.querySelector('input[name="stage"][value="'+sv+'"]');
    if(sr)sr.checked=true;
  }catch(e){}
  document.querySelectorAll('input[name="stage"]').forEach(function(r){
    r.addEventListener('change',function(){try{localStorage.setItem('prof-stage',r.value);}catch(e){}renderHalls();});
  });

  /* ---------- lecturer actions (same rules for halls and labs) ---------- */
  async function book(id){
    var f=fac,L=FAC[f],num=L.ids.indexOf(id)+1,stg=selStage();
    if(!me){say('أدخل رمز الأستاذ أولاً.',true);$('#code').focus();return;}
    busy[id]=true;renderHalls();
    try{
      await api('POST','/api/book',{fac:f,place:id,stage:stg});
      say('تم حجز '+L.one+' '+ar(num)+' للمرحلة '+stageName(stg)+' باسم '+me.name+'.');
    }catch(e){
      var c=e.data&&e.data.code;
      if(c==='place_booked')say(L.justBooked,true);
      else if(c==='stage_taken')say('المرحلة '+stageName(stg)+' محجوزة أصلاً في '+L.one+' '+ar(L.ids.indexOf(e.data.place)+1)+' باسم '+(e.data.professor||'—')+'.',true);
      else if(e.status===401)say('انتهت جلستك أو لم يعد رمزك مفعلاً. أدخل الرمز من جديد أو راجع رئيس القسم.',true);
      else if(e.network)say('تعذر الاتصال بالسيرفر.',true);
      else say('تعذر الحفظ، حاول مرة ثانية.',true);
    }finally{busy[id]=false;await refresh();renderAll();}
  }
  async function leave(id){
    var f=fac,L=FAC[f];
    busy[id]=true;confirmId=null;renderHalls();
    try{
      await api('POST','/api/leave',{fac:f,place:id});
      say('تم تسجيل مغادرتك من '+L.one+' '+ar(L.ids.indexOf(id)+1)+'.');
    }catch(e){
      var c=e.data&&e.data.code;
      if(c==='not_owner')say(L.busyOther+'.',true);
      else if(e.status===401)say('انتهت جلستك. أدخل الرمز من جديد.',true);
      else if(e.network)say('تعذر الاتصال بالسيرفر.',true);
      else say('تعذر الحفظ، حاول مرة ثانية.',true);
    }finally{busy[id]=false;await refresh();renderAll();}
  }
  $('#hall-grid').addEventListener('click',function(ev){
    var b=ev.target.closest('button[data-id]');
    if(!b||b.disabled)return;
    var id=b.dataset.id;
    if(b.dataset.act==='book'){book(id);return;}
    if(confirmId===id){clearTimeout(confirmTimer);leave(id);return;}
    confirmId=id;renderHalls();
    clearTimeout(confirmTimer);
    confirmTimer=setTimeout(function(){confirmId=null;renderHalls();},4000);
  });

  /* ---------- department head actions ---------- */
  $('#h-tabs').addEventListener('click',function(ev){
    var b=ev.target.closest('button[data-t]');
    if(!b)return;
    hTab=b.dataset.t;renderAll();
  });
  $('#a-add').addEventListener('click',async function(){
    var nm=$('#a-name').value.trim(),cd=$('#a-code').value.trim();
    if(!head)return;
    if(!nm||cd.length<4){say('اكتب الاسم ورمزاً من أربعة أحرف أو أرقام على الأقل.',true);return;}
    try{
      await api('POST','/api/professors',{name:nm,code:cd});
      $('#a-name').value='';$('#a-code').value='';
      say('أُضيف '+nm+'. الرمز الذي يسلَّم له: '+cd);
    }catch(e){
      if(e.data&&e.data.code==='code_used')say('هذا الرمز مستخدم لأستاذ آخر، اختر رمزاً مختلفاً.',true);
      else if(e.status===401)say('انتهت جلسة رئيس القسم. سجّل الدخول من جديد.',true);
      else say('تعذر الحفظ، حاول مرة ثانية.',true);
    }
    await refresh();renderAll();
  });
  $('#plist').addEventListener('click',async function(ev){
    var b=ev.target.closest('button[data-pid]');
    if(!b||!head)return;
    var pid=b.dataset.pid;
    if(delId!==pid){
      delId=pid;renderProfs();
      clearTimeout(delTimer);
      delTimer=setTimeout(function(){delId=null;renderProfs();},4000);
      return;
    }
    clearTimeout(delTimer);delId=null;
    try{await api('DELETE','/api/professors/'+encodeURIComponent(pid));say('تمت إزالة الأستاذ.');}
    catch(e){say('تعذرت الإزالة، حاول مرة ثانية.',true);}
    await refresh();renderAll();
  });

  /* ---------- routing: #home (default), #head, #prof, #students, #reader ---------- */
  function route(){
    var h=location.hash.slice(1),lm=/^log-([1-4])$/.exec(h);
    if(lm){curView='log';logStage=Number(lm[1]);}
    else{curView=VIEWS.indexOf(h)>=0?h:'home';logStage=0;}
    var key=lm?'log-'+logStage:curView;
    /* remember where we came from; switching between stages inside the history page is not a new step */
    if(!goingBack&&key!==lastKey&&!(/^log-/.test(key)&&/^log-/.test(lastKey))){
      navStack.push(lastKey);
      if(navStack.length>30)navStack.shift();
    }
    goingBack=false;lastKey=key;
    $('#back').hidden=curView==='home';
    VIEWS.forEach(function(n){var s=$('#v-'+n);if(s)s.hidden=n!==curView;});
    $('#shell').hidden=curView==='home';
    $('#home-link').hidden=curView==='home';
    if(curView==='log')$('#log-link').setAttribute('aria-current','page');
    else $('#log-link').removeAttribute('aria-current');
    confirmId=null;
    ['#msg','#h-msg'].forEach(function(s){var m=$(s);m.textContent='';m.className='msg';});
    if(curView==='students')$('#q-text').textContent=nextQuote();
    if(curView==='log')watchLog();else stopLog();
    renderAll();
  }
  window.addEventListener('hashchange',route);
  $('#back').addEventListener('click',function(){
    var prev=navStack.pop()||'home';
    if(prev===lastKey)prev='home';
    if(location.hash.slice(1)===prev){route();return;}
    goingBack=true;
    location.hash='#'+prev;
  });

  /* ---------- start ---------- */
  route();tick();
  refresh();
  setInterval(function(){if(!document.hidden)refresh();},3000);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)refresh();});
})();
