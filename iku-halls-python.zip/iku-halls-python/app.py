#!/usr/bin/env python3
"""
موقع قاعات ومختبرات كلية الهندسة - جامعة الإمام الكاظم
نسخة بايثون: Flask + SQLite

التشغيل:
    pip install -r requirements.txt
    python app.py                 ثم افتح http://localhost:5000

أوامر الإدارة (من سطر الأوامر):
    python app.py list                          عرض رئيس القسم والأساتذة
    python app.py add-prof  "د. أحمد" Aa1234    إضافة أستاذ
    python app.py del-prof  3                   إزالة أستاذ برقمه (من list)
    python app.py set-head  "رئيس القسم" NEW99  تغيير رمز رئيس القسم
"""
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, g, jsonify, request, send_from_directory, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("IKU_DB", os.path.join(BASE_DIR, "halls.db"))
KEY_PATH = os.environ.get("IKU_KEY_FILE", os.path.join(BASE_DIR, "secret.key"))

# ---------------------------------------------------------------- الإعدادات
# أربع قاعات وأربعة مختبرات، مشتركة بين المراحل الأربع.
FACILITIES = {
    "halls": ["h1", "h2", "h3", "h4"],
    "labs": ["l1", "l2", "l3", "l4"],
}
STAGES = (1, 2, 3, 4)
BAGHDAD = timezone(timedelta(hours=3))  # توقيت بغداد ثابت (بدون توقيت صيفي)

# رموز البداية عند أول تشغيل فقط. غيّرها فوراً (انظر README).
DEFAULT_HEAD_CODE = os.environ.get("IKU_HEAD_CODE", "admn99")
SEED_PROFESSORS = [("د. محمد فاضل", "Mm1234"), ("د. فاطمة", "Ff1234")]

MAX_FAILED_LOGINS = 8      # محاولات خاطئة مسموحة
FAILED_WINDOW_SEC = 300    # خلال هذه المدة (5 دقائق)


def load_secret():
    """مفتاح سري يُنشأ مرة واحدة ويُحفظ بجانب الموقع. لا ترفعه لأي مكان عام."""
    env = os.environ.get("IKU_SECRET")
    if env:
        return env.encode()
    if os.path.exists(KEY_PATH):
        with open(KEY_PATH, "rb") as f:
            return f.read().strip()
    key = secrets.token_hex(32).encode()
    fd = os.open(KEY_PATH, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(key)
    return key


SECRET = load_secret()

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config.update(
    SECRET_KEY=SECRET,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("IKU_COOKIE_SECURE") == "1",  # فعّله مع HTTPS
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),
    JSON_AS_ASCII=False,
)
if os.environ.get("IKU_PROXY") == "1":  # خلف nginx أو استضافة وسيطة
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)


# ------------------------------------------------------------ قاعدة البيانات
SCHEMA = """
CREATE TABLE IF NOT EXISTS professors (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    code_hash TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS heads (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    code_hash TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS bookings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    fac        TEXT    NOT NULL,           -- halls أو labs
    place      TEXT    NOT NULL,           -- h1..h4 أو l1..l4
    prof_id    INTEGER,
    professor  TEXT    NOT NULL,
    stage      INTEGER NOT NULL,           -- 1..4
    started_at INTEGER NOT NULL,           -- بالمللي ثانية (UTC)
    ended_at   INTEGER,                    -- NULL = ما زال محجوزاً
    day        TEXT    NOT NULL            -- YYYY-MM-DD بتوقيت بغداد
);
CREATE INDEX IF NOT EXISTS ix_bookings_day ON bookings(day);
-- قاعدة البيانات نفسها تمنع التعارض حتى لو ضغط أستاذان بنفس اللحظة:
CREATE UNIQUE INDEX IF NOT EXISTS ux_active_place ON bookings(fac, place) WHERE ended_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_active_stage ON bookings(fac, stage) WHERE ended_at IS NULL;
"""


def connect():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    return db


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def code_hash(code: str) -> str:
    """الرمز لا يُخزَّن نصاً: يُحفظ ناتج HMAC-SHA256 بالمفتاح السري."""
    return hmac.new(SECRET, code.encode("utf-8"), hashlib.sha256).hexdigest()


def now_ms() -> int:
    return int(time.time() * 1000)


def day_key(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, BAGHDAD).strftime("%Y-%m-%d")


def init_db():
    db = connect()
    with db:
        db.executescript(SCHEMA)
        if db.execute("SELECT COUNT(*) FROM heads").fetchone()[0] == 0:
            db.execute("INSERT INTO heads(name, code_hash) VALUES (?,?)",
                       ("رئيس القسم", code_hash(DEFAULT_HEAD_CODE)))
            for name, code in SEED_PROFESSORS:
                db.execute("INSERT OR IGNORE INTO professors(name, code_hash) VALUES (?,?)",
                           (name, code_hash(code)))
    db.close()


# ------------------------------------------------------------- الدخول والحماية
_failed = defaultdict(deque)  # عنوان الجهاز -> أوقات المحاولات الخاطئة


def too_many_failures(ip: str) -> bool:
    q = _failed[ip]
    cutoff = time.time() - FAILED_WINDOW_SEC
    while q and q[0] < cutoff:
        q.popleft()
    return len(q) >= MAX_FAILED_LOGINS


def current_user(kind: str):
    """المستخدم المسجّل من الجلسة، بشرط أن يكون ما زال موجوداً في القاعدة."""
    uid = session.get(kind + "_id")
    if not uid:
        return None
    table = "professors" if kind == "prof" else "heads"
    row = get_db().execute(f"SELECT id, name FROM {table} WHERE id=?", (uid,)).fetchone()
    if row is None:  # أُزيل الأستاذ: تنتهي جلسته فوراً
        session.pop(kind + "_id", None)
        return None
    return row


def require(kind):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            user = current_user(kind)
            if user is None:
                return jsonify(code="unauthorized"), 401
            g.user = user
            return fn(*a, **kw)
        return wrapper
    return deco


@app.before_request
def csrf_guard():
    # أي طلب يغيّر شيئاً لازم يحمل هذا الترويس (المواقع الأخرى لا تستطيع إرساله).
    if request.path.startswith("/api/") and request.method not in ("GET", "HEAD", "OPTIONS"):
        if request.headers.get("X-Requested-With") != "iku":
            return jsonify(code="bad_request"), 400


@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; "
        "style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
        "img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'"
    )
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


# --------------------------------------------------------------- الصفحات
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# -------------------------------------------------------------------- الواجهة
def places_state(db, prof_id):
    """آخر حالة لكل قاعة ومختبر: محجوز، أو متاح (مع آخر محاضرة إن وُجدت)."""
    rows = db.execute(
        """SELECT b.* FROM bookings b
           JOIN (SELECT fac, place, MAX(id) AS mid FROM bookings GROUP BY fac, place) m
             ON b.id = m.mid"""
    ).fetchall()
    out = {fac: {} for fac in FACILITIES}
    for r in rows:
        if r["fac"] not in FACILITIES or r["place"] not in FACILITIES[r["fac"]]:
            continue
        booked = r["ended_at"] is None
        out[r["fac"]][r["place"]] = {
            "status": "booked" if booked else "free",
            "professor": r["professor"],
            "stage": r["stage"],
            "startedAt": r["started_at"],
            "endedAt": r["ended_at"],
            # هل الحجز يخص الأستاذ المسجّل الآن؟ (يتحكم بزر المغادرة)
            "mine": bool(booked and prof_id is not None and r["prof_id"] == prof_id),
        }
    return out


@app.get("/api/state")
def state():
    db = get_db()
    prof, head = current_user("prof"), current_user("head")
    body = {
        "now": now_ms(),
        **places_state(db, prof["id"] if prof else None),
        "me": {"id": str(prof["id"]), "name": prof["name"]} if prof else None,
        "head": {"id": str(head["id"]), "name": head["name"]} if head else None,
    }
    if head:  # قائمة الأساتذة لرئيس القسم فقط
        body["professors"] = [
            {"id": str(r["id"]), "name": r["name"]}
            for r in db.execute("SELECT id, name FROM professors ORDER BY name")
        ]
    return jsonify(body)


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    kind = data.get("kind")
    code = str(data.get("code") or "").strip()
    if kind not in ("prof", "head") or not code or len(code) > 40:
        return jsonify(code="bad_request"), 400
    ip = request.remote_addr or "?"
    if too_many_failures(ip):
        return jsonify(code="too_many"), 429
    table = "professors" if kind == "prof" else "heads"
    row = get_db().execute(
        f"SELECT id, name FROM {table} WHERE code_hash=?", (code_hash(code),)
    ).fetchone()
    if row is None:
        _failed[ip].append(time.time())
        return jsonify(code="bad_code"), 401
    session.permanent = True
    session[kind + "_id"] = row["id"]
    return jsonify(ok=True, name=row["name"])


@app.post("/api/logout")
def logout():
    data = request.get_json(silent=True) or {}
    if data.get("kind") in ("prof", "head"):
        session.pop(data["kind"] + "_id", None)
    return jsonify(ok=True)


@app.post("/api/book")
@require("prof")
def book():
    data = request.get_json(silent=True) or {}
    fac, place, stage = data.get("fac"), data.get("place"), data.get("stage")
    if fac not in FACILITIES or place not in FACILITIES[fac] or stage not in STAGES:
        return jsonify(code="bad_request"), 400
    db = get_db()
    started = now_ms()
    try:
        with db:
            db.execute(
                """INSERT INTO bookings(fac, place, prof_id, professor, stage, started_at, day)
                   VALUES (?,?,?,?,?,?,?)""",
                (fac, place, g.user["id"], g.user["name"], stage, started, day_key(started)),
            )
    except sqlite3.IntegrityError:
        if db.execute("SELECT 1 FROM bookings WHERE fac=? AND place=? AND ended_at IS NULL",
                      (fac, place)).fetchone():
            return jsonify(code="place_booked"), 409
        other = db.execute(
            "SELECT place, professor FROM bookings WHERE fac=? AND stage=? AND ended_at IS NULL",
            (fac, stage),
        ).fetchone()
        return jsonify(code="stage_taken", place=other["place"] if other else None,
                       professor=other["professor"] if other else None), 409
    return jsonify(ok=True, startedAt=started)


@app.post("/api/leave")
@require("prof")
def leave():
    data = request.get_json(silent=True) or {}
    fac, place = data.get("fac"), data.get("place")
    if fac not in FACILITIES or place not in FACILITIES[fac]:
        return jsonify(code="bad_request"), 400
    db = get_db()
    with db:
        cur = db.execute(
            """UPDATE bookings SET ended_at=?
               WHERE fac=? AND place=? AND ended_at IS NULL AND prof_id=?""",
            (now_ms(), fac, place, g.user["id"]),
        )
    if cur.rowcount == 1:
        return jsonify(ok=True)
    active = db.execute("SELECT 1 FROM bookings WHERE fac=? AND place=? AND ended_at IS NULL",
                        (fac, place)).fetchone()
    # محجوز لأستاذ آخر: ممنوع على الجميع (حتى رئيس القسم وصاحب الموقع)
    return (jsonify(code="not_owner"), 403) if active else (jsonify(code="not_booked"), 404)


@app.get("/api/log")
def booking_log():
    day = request.args.get("day", "")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
        return jsonify(code="bad_request"), 400
    rows = get_db().execute(
        """SELECT fac, place, professor, stage, started_at, ended_at
           FROM bookings WHERE day=? ORDER BY started_at""", (day,)
    ).fetchall()
    return jsonify(items=[
        {"fac": r["fac"], "place": r["place"], "professor": r["professor"],
         "stage": r["stage"], "startedAt": r["started_at"], "endedAt": r["ended_at"]}
        for r in rows
    ])


# ------------------------------------------------------- إدارة الأساتذة (رئيس القسم)
@app.post("/api/professors")
@require("head")
def add_professor():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name") or "").strip()
    code = str(data.get("code") or "").strip()
    if not name or len(name) > 60 or len(code) < 4 or len(code) > 40:
        return jsonify(code="bad_request"), 400
    try:
        with get_db() as db:
            db.execute("INSERT INTO professors(name, code_hash) VALUES (?,?)",
                       (name, code_hash(code)))
    except sqlite3.IntegrityError:
        return jsonify(code="code_used"), 409
    return jsonify(ok=True)


@app.delete("/api/professors/<int:pid>")
@require("head")
def remove_professor(pid):
    with get_db() as db:
        # إذا كان عند الأستاذ حجز جارٍ يُنهى حتى لا تبقى القاعة مقفولة.
        db.execute("UPDATE bookings SET ended_at=? WHERE prof_id=? AND ended_at IS NULL",
                   (now_ms(), pid))
        db.execute("DELETE FROM professors WHERE id=?", (pid,))
    return jsonify(ok=True)


# ------------------------------------------------------------- سطر الأوامر
def cli(argv):
    cmd = argv[0]
    db = connect()
    try:
        if cmd == "list":
            print("رئيس القسم:")
            for r in db.execute("SELECT id, name FROM heads"):
                print(f"  [{r['id']}] {r['name']}")
            print("الأساتذة:")
            for r in db.execute("SELECT id, name FROM professors ORDER BY name"):
                print(f"  [{r['id']}] {r['name']}")
        elif cmd == "add-prof" and len(argv) == 3:
            with db:
                db.execute("INSERT INTO professors(name, code_hash) VALUES (?,?)",
                           (argv[1], code_hash(argv[2])))
            print("تمت الإضافة.")
        elif cmd == "del-prof" and len(argv) == 2:
            with db:
                db.execute("UPDATE bookings SET ended_at=? WHERE prof_id=? AND ended_at IS NULL",
                           (now_ms(), int(argv[1])))
                db.execute("DELETE FROM professors WHERE id=?", (int(argv[1]),))
            print("تمت الإزالة.")
        elif cmd == "set-head" and len(argv) == 3:
            with db:
                db.execute("DELETE FROM heads")
                db.execute("INSERT INTO heads(name, code_hash) VALUES (?,?)",
                           (argv[1], code_hash(argv[2])))
            print("تم تغيير رمز رئيس القسم.")
        else:
            print(__doc__)
            return 1
    except sqlite3.IntegrityError:
        print("هذا الرمز مستخدم لشخص آخر، اختر رمزاً مختلفاً.")
        return 1
    finally:
        db.close()
    return 0


init_db()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(cli(sys.argv[1:]))
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    print(f"الموقع يعمل على http://localhost:{port}")
    app.run(host=host, port=port, debug=False, threaded=True)
