# ===== الصق هذا الملف كاملاً داخل "WSGI configuration file" في PythonAnywhere =====
# غيّر السطر التالي فقط: اكتب اسم حسابك في PythonAnywhere بدل USERNAME
USERNAME = "USERNAME"

import os
import sys

PROJECT = "/home/%s/iku-halls-python" % USERNAME
if PROJECT not in sys.path:
    sys.path.insert(0, PROJECT)

os.environ["IKU_COOKIE_SECURE"] = "1"   # الموقع يعمل بـ HTTPS
os.environ["IKU_PROXY"] = "1"           # الاستضافة خلف وسيط
os.environ["IKU_DB"] = os.path.join(PROJECT, "halls.db")
os.environ["IKU_KEY_FILE"] = os.path.join(PROJECT, "secret.key")

from app import app as application  # noqa: E402
